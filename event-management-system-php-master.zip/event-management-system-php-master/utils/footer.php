<hr class = "footerline"><!--css modified horizontal line-->
<footer style="background:black;">
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                      <h3>Event Management System</h3>
                    </p>

                    <p class = "footerSubtext2">
                        Copyright @Event Management System
                    </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make
                </div>
                <p id="dateAndTime"></p>

            </section>
            <section>

            </section>
        </div>
    </div>
</footer>
