Login details:

username: user
password: user